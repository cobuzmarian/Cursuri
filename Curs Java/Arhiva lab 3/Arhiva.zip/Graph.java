/*
 * Programare orientata pe obiecte
 * Seria CC
 * Laboratorul 3
 * Exemplul 3
 * Anul universitar 2015-2016
 * Nan Mihai
 */

public class Graph {

	public int[][] floydWarshall() {
		int result[][];
		result = new int[this.nrVarfuri][this.nrVarfuri];
		int k, i, j;
		for(i = 1; i <= this.nrVarfuri; i++) {
			for(j = 1; j <= this.nrVarfuri; j++) {
				if(i == j) {
					result[i][j] = 0;
				} else if(this.isArc(i, j)) {
					result[i][j] = this.matrice[i][j];
				} else {
					result[i][j] = Infinit;
				}
			}
		}
		for(k = 1; k <= this.nrVarfuri; k++) {
			for(i = 1; i <= this.nrVarfuri; i++) {
				for(j = 1; j <= this.nrVarfuri; j++) {
					int dist;
					dist = result[i][k] + result[k][j];
					if(result[i][j] > dist) {
						result[i][j] = dist;
					}
				}
			}
		}
		return result;
	}

	public static void main(String args[]) {
        Graph g = new Graph(8);
        g.addArc(4, 6, 2);
        g.addArc(4, 5, 3);
        g.addArc(5, 1, 1);
        g.addArc(1, 2, 5);
        g.addArc(2, 5, 7);
        g.addArc(2, 3, 6);
        g.addArc(3, 4, 3);
        g.addArc(0, 6, 15);
        g.addArc(0, 4, 1);
        g.addArc(5, 0, 6);
        g.addArc(7, 4, 2);
        g.addArc(7, 5, 4);
        System.out.println(g);
    }
}