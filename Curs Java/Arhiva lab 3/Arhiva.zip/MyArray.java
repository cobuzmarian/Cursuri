/*
 * Programare orientata pe obiecte
 * Seria CC
 * Laboratorul 3 - 325CC
 * Clasa auxiliara
 * Anul universitar 2015-2016
 * Nan Mihai
 */

public class MyArray {
    private int v[];
    private int size;
    
    public MyArray() {
        this(100);
    }
    
    public MyArray(int length) {
        this.size = 0;
        v = new int[length];
    }
    
    public int get(int poz) {
        if(poz < size) {
            return v[poz];
        } else {
            return -1;
        }
    }
    
    public void set(int pos, int value) {
        v[pos] = value;
        size++;
    }
    
    public int getSize() {
        return this.size;
    }
}