/*
 * Programare orientata pe obiecte
 * Seria CC
 * Laboratorul 3
 * Exemplul 3
 * Anul universitar 2015-2016
 * Nan Mihai
 */

class Test {
    public int maxim(int a, int b) {
        if(a > b) {
            return a;
        } else {
            return b;
        }
    }
    
    public int maxim(String s1, String s2) {
        if(s1.compareTo(s2) < 0) {
            return 2;
        } else {
            return 1;
        }
    }
    
    public int maxim(int a, int b, int c) {
        if(maxim(a, b) < c) {
            return c;
        } else {
            return maxim(a, b);
        }
    }
}