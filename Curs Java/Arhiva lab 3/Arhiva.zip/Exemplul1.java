/*
 * Programare orientata pe obiecte
 * Seria CC
 * Laboratorul 3
 * Exemplul 1
 * Anul universitar 2015-2016
 * Nan Mihai
 */

class Carte {
    String nume, autor;
    int nr_pagini;
    
    public Carte(String nume, String autor, int nr_pagini) {
        this.nume = nume;
        this.autor = autor;
        this.nr_pagini = nr_pagini;
    }
    
    public Carte() {
        this("Enigma Otiliei", "George Calinescu", 423);
    }
    
    public String toString() {
        String result = "";
        result += this.autor + ", " + this.nume;
        result += " - " + this.nr_pagini;
        return result;
    }
    
    public static void main(String args[]) {
        Carte carte;
        carte = new Carte("Poezii", "Mihai Eminescu", 256);
        System.out.println(carte.toString());
    }
}