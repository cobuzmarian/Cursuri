import java .io .*;
import java . awt .*;
import java . awt. event .*;
import java . awt. print .*;
import javax . swing .*;
class Plansa extends Canvas implements Printable {
	Dimension d = new Dimension (400 , 400) ;
	public Dimension getPreferredSize () {	return d; } 
	public void paint ( Graphics g) {
		g. drawRect (200 , 200 , 100 , 100) ;
		g. drawOval (200 , 200 , 100 , 100) ;
		g. drawString (" Hello ", 200 , 200) ;
	}
	public int print ( Graphics g, PageFormat pf , int pi) throws PrinterException {
		if (pi >= 1) return Printable . NO_SUCH_PAGE ;
		paint (g);
		g. drawString (" Numai la imprimanta ", 200 , 300) ;
		return Printable . PAGE_EXISTS ;
	}
}
class Fereastra extends JFrame implements ActionListener {
	private Plansa plansa = new Plansa ();
	private Button print = new Button (" Print ");
	public Fereastra ( String titlu ) {
		super ( titlu );
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		addWindowListener ( new WindowAdapter () {
			public void windowClosing ( WindowEvent e) {
				System . exit (0);
			}
		});
	add (plansa , BorderLayout . CENTER );
	Panel south = new Panel ();
	south . setLayout (new FlowLayout ( FlowLayout . CENTER ));
	south .add( print );
	add (south , BorderLayout . SOUTH );
	print . addActionListener ( this );
	pack ();
  }
  public void actionPerformed ( ActionEvent e) {
	// 1. Crearea unei sesiuni de tiparire
	PrinterJob printJob = PrinterJob . getPrinterJob ();
	// 2. Stabilirea obiectului ce va fi tiparit
	printJob . setPrintable ( plansa );
	// 3. Initierea dialogului cu utilizatorul
	if ( printJob . printDialog ()) {
		try {
			// 4. Tiparirea efectiva
			printJob . print ();
		} catch ( PrinterException ex) {
		System . out. println (" Exceptie la tiparire !");
		ex. printStackTrace ();}
	}
  }
}
class TestPrint {
	public static void main ( String args []) throws Exception {
		Fereastra f = new Fereastra (" Test Print ");
		f. show ();
	}
}
