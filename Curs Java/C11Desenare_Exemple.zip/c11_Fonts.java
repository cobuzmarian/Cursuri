import java . awt .*;
import javax . swing .*;

class Fonturi extends Canvas {
	private Font [] fonturi ;
	Dimension canvasSize = new Dimension (400 , 400) ;
	public Fonturi () {
		fonturi = GraphicsEnvironment .
		       getLocalGraphicsEnvironment (). getAllFonts ();
		canvasSize . height = (1 + fonturi . length ) * 20;
	}
	public void paint ( Graphics g) {
		String nume ;
		for (int i=0; i < fonturi . length ; i ++) {
		   nume = fonturi [i]. getFontName ();
		   g. setFont (new Font (nume , Font .PLAIN , 14));
		   g. drawString (i + ". " + nume , 20, (i + 1) * 20);
		}
	}
	public Dimension getPreferredSize () {
		return canvasSize ;
	}
}

class Fereastra extends JFrame {
	public Fereastra ( String titlu ) {
		super ( titlu );
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		ScrollPane sp = new ScrollPane ();
		sp. setSize (400 , 400) ;
		sp.add( new Fonturi ());
		add (sp , BorderLayout . CENTER );
		pack ();
	}
}
class TestAllFonts {
	public static void main ( String args []) {
		new Fereastra ("All fonts "). show ();
	}
}
