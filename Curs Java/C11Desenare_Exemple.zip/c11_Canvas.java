import java . awt .*;
import java . awt. event .*;
import javax . swing .*;

class Plansa extends Canvas {
	Dimension dim = new Dimension (100 , 100) ;
	private Color color [] = { Color .red , Color . blue };
	private int index = 0;
	public Plansa () {
		this . addMouseListener (new MouseAdapter () {
			public void mouseClicked ( MouseEvent e) {
				index = 1 - index ;
				repaint ();
			}
		});
	}
	public void paint ( Graphics g) {
		g. setColor ( color [ index ]);
		g. drawRect (0, 0, dim .width , dim. height );
		g. setColor ( color [1 - index ]);
		g. fillOval (0, 0, dim .width , dim. height );
	}
	public Dimension getPreferredSize () {
		return dim ;
	}
}
class Fereastra extends JFrame {
	public Fereastra ( String titlu ) {
		super ( titlu );
		setSize (200 , 200) ;
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		add (new Plansa () , BorderLayout . CENTER );
	}
}
class TestCanvas {
	public static void main ( String args []) {
		new Fereastra (" Test Canvas "). show ();
	}
}

