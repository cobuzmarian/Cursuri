import java . awt .*;
import javax . swing .*;
class Fereastra extends JFrame {
	public Fereastra ( String titlu ) {
		super ( titlu );
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize (200 , 100) ;
	}
	public void paint ( Graphics g) {
		// Apelam metoda paint a clasei Frame
		super . paint (g);
		g. setFont (new Font (" Arial ", Font .BOLD , 11));
		g. setColor ( Color .red );
		g. drawString (" Aplicatie DEMO ", 5, 50);
	}
}
class TestPaint {
	public static void main ( String args []) {
		Fereastra f = new Fereastra (" Test paint ");
		f. show ();
	}
}
